package nkt.entity;

public class StandB extends Stand {

}
