package nkt.entity;

public class StandC extends Stand{

}
