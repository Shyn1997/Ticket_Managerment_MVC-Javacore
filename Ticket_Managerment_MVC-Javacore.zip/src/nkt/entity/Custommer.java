package nkt.entity;

public class Custommer {
	 private int identitycard;
	 private String name;
	 
	public int getIdentitycard() {
		return identitycard;
	}
	public void setIdentitycard(int identitycard) {
		this.identitycard = identitycard;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
