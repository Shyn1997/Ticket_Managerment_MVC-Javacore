package nkt.entity;

public class StandA extends Stand {
	private String seatingVip;
	private int check;

	
	public String getSeatingVip() {
		return seatingVip;
	}
	public void setSeatingVip(String seatingVip) {
		this.seatingVip = seatingVip;
	}
	public int getCheck() {
		return check;
	}
	public void setCheck(int check) {
		this.check = check;
	}
}
