package nkt.entity;

public class StandD extends Stand {
	
}
