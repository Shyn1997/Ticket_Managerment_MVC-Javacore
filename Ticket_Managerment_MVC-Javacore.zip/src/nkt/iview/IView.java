package nkt.iview;

import java.util.List;

import nkt.entity.Seat;
import nkt.entity.StandA;
import nkt.entity.Stand;

public interface IView {

}
